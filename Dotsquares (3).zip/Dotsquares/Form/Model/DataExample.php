<?php 
namespace Dotsquares\Form\Model;
class DataExample extends \Magento\Framework\Model\AbstractModel{
    public function _construct(){
        $this->_init("Dotsquares\Form\Model\ResourceModel\DataExample");
    }
}
 ?>