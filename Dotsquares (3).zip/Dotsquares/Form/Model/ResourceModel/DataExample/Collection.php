<?php 
namespace Dotsquares\Form\Model\ResourceModel\DataExample;
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection{
    public function _construct(){
        $this->_init("Dotsquares\Form\Model\DataExample","Dotsquares\Form\Model\ResourceModel\DataExample");
    }
}
 ?>
