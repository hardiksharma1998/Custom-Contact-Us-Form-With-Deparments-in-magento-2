<?php
namespace Dotsquares\Form\Controller\Form;

use Zend\Log\Filter\Timestamp;
use Magento\Store\Model\StoreManagerInterface;
use Dotsquares\Form\Model\DataExampleFactory;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\View\Result\PageFactory;


class Postmail extends \Magento\Framework\App\Action\Action
{
    const XML_PATH_EMAIL_RECIPIENT_NAME = 'trans_email/ident_support/name';
    const XML_PATH_EMAIL_RECIPIENT_EMAIL = 'trans_email/ident_support/email';
    const XML_PATH_EMAIL_RECIPIENT_DEPARTMENTS = 'trans_email/ident_support/departments';
    const XML_PATH_EMAIL_RECIPIENT_DELIVERY = 'trans_email/ident_support/delivery';
    const XML_PATH_EMAIL_RECIPIENT_CHECKBOX = 'trans_email/ident_support/checkbox';

    
    protected $_inlineTranslation;
    protected $_transportBuilder;
    protected $_scopeConfig;
    protected $_logLoggerInterface;
    protected $storeManager;
    protected $dataExample;
    protected $resultPageFactory;




    public function __construct(
        Magento\Framework\App\Action\Context $context,
        Magento\Framework\Translate\Inline\StateInterface $inlineTranslation,
        Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
        Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        Psr\Log\LoggerInterface $loggerInterface,
        StoreManagerInterface $storeManager,
        DataExampleFactory $dataExample,
        PageFactory $resultPageFactory,
        array $data = []
    )
    {
        $this->_inlineTranslation = $inlineTranslation;
        $this->_transportBuilder = $transportBuilder;
        $this->_scopeConfig = $scopeConfig;
        $this->_logLoggerInterface = $loggerInterface;
        $this->messageManager = $context->getMessageManager();
        $this->storeManager = $storeManager;
        $this->dataExample = $dataExample;
        $this->resultPageFactory = $resultPageFactory;
        parent::__construct($context);
 }

    public function execute()
    {

      $post = $this->getRequest()->getPost();
        

       error_reporting("error happens");

        try
        {
            // Send Mail
            $this->_inlineTranslation->suspend();

            $sender = [
                'name' => $post['name'],
                'email' => $post['email'],
                 'departments' => $post['customer_status'],
                  'delivery' => $post['delivery'],
                  'checkbox' => $post['checkbox']
            ];

      
            $sentToEmail = $this->_scopeConfig ->getValue('trans_email/ident_general/email',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);

            $sentToName = $this->_scopeConfig ->getValue('trans_email/ident_general/name',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
         
            $sentToDepartments = $this->_scopeConfig ->getValue('trans_email/ident_general/departments',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    
            $sentToDelivery = $this->_scopeConfig ->getValue('trans_email/ident_general/delivery',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);

            $sentToCheckbox = $this->_scopeConfig ->getValue('trans_email/ident_general/checkbox',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);



            $transport = $this->_transportBuilder
                ->setTemplateIdentifier('eyetest_email_template')
                ->setTemplateOptions(
                    [
                        'area' => 'frontend',
                        'store' => $this->storeManager->getStore()->getId()
                    ]
                )
                ->setTemplateVars([
                    'name'  => $post['name'],
                    'email'  => $post['email'],
                    'departments' => $post['customer_status'],
                     'delivery' => $post['delivery'],
                     'checkbox' => $post['checkbox']


                ])
                
                

                ->setFrom($sender)
                ->addTo($post['customer_status'])
                ->getTransport();

  
               $dataSave = $this->dataExample->create();

                $data = [
              'name' => $post['name'],
              'email' => $post['email'],
              'departments' => $post['customer_status'],
              'delivery' => $post['delivery'],
              'checkbox' =>  $post['checkbox']
                ];
           
        
            $dataSave->setData($data);
            $dataSave->save();
            
            $transport->sendMessage();

            $this->_inlineTranslation->resume();
            $this->messageManager->addSuccess('Email sent successfully');
            $this->_redirect('eyetest/form');

        }
         catch(\Exception $e)
         {
            $this->messageManager->addError($e->getMessage());
            $this->_logLoggerInterface->debug($e->getMessage());
            exit;
        }



    }
}